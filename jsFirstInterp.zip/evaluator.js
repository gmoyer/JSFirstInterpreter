class Evaluator{
  isTypeVariableDeclaration(node) {
    return node.type == 'VariableDeclaration';
  }
}
module.exports=Evaluator;
// a script that loads, parses and evaluates a sample program.

const Getnodes = require("./getnodes");

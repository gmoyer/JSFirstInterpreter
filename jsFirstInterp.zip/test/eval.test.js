const Getnodes = require("./../getnodes");
const Evaluator = require("./../evaluator");
let body ;

beforeAll( ()=>{
  const getNodes = new Getnodes();
  body = getNodes.parseProgram(getNodes.loadFile('test\\sample.js'));
  console.log(body);
})

test('two nodes parsed ', ()=>{
  expect(body.length).toBe(2);
})
test('node of type VariableDeclaration', () => {
    const evaluator = new Evaluator();
    expect(evaluator.isTypeVariableDeclaration(body[0])).toBe(true);
    expect(evaluator.isTypeVariableDeclaration(body[1])).toBe(false);
})


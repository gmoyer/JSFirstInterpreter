const a = "hello"

print (a)